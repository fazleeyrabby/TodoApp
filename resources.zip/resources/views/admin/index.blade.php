@extends('layouts.admin_master')

@section('content')



@include('admin.includes.dashboard')


@endsection